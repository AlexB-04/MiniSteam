﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiniSteam.Data;
using MiniSteam.Models.Entities;

namespace MiniSteam.Controllers
{
    [Authorize(Roles = "Admin")]
    public class GenresController : Controller
    {
        // Контроллер GenresController, который управляет действиями, связанными с жанрами в приложении MiniSteam.
        private readonly DataContext _context;

        // Конструктор класса GenresController, который принимает экземпляр DataContext и сохраняет его в приватное поле _context.
        public GenresController(DataContext context)
        {
            _context = context;
        }

        // GET: Genres
        public IActionResult Index()
        {
            return View(_context.Genres.OrderBy(genre => genre.Name));
        }

        // GET: Genres/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Genres/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Genre genre)
        {
            if (ModelState.IsValid)
            {
                _context.Genres.Add(genre);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(genre);
        }

        // GET: Genres/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var genre = await _context.Genres.FirstOrDefaultAsync(g => g.Id == id);

            if (genre == null)
            {
                return NotFound();
            }

            return View(genre);
        }

        // GET: Genres/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var genre = await _context.Genres.FindAsync(id);

            if (genre == null)
            {
                return NotFound();
            }

            return View(genre);
        }

        // POST: Genres/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Genre genre)
        {
            if (ModelState.IsValid)
            {
                if (!await _context.Genres.AnyAsync(g => g.Id == genre.Id))
                {
                    return NotFound();
                }

                _context.Genres.Update(genre);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));
            }

            return View(genre);
        }

        // GET: Genres/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var genre = await _context.Genres.FindAsync(id);

            if (genre == null)
            {
                return NotFound();
            }

            return View(genre);
        }

        // POST: Genres/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var isUsed = await _context.Games.AnyAsync(game => game.GenreId == id);

            if (isUsed)
            {
                TempData["ErrorMessage"] = "This genre cannot be deleted because it is used by one or more games.";
                return RedirectToAction(nameof(Index));
            }

            var genre = await _context.Genres.FindAsync(id);

            if (genre == null)
            {
                return NotFound();
            }

            _context.Genres.Remove(genre);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}