﻿using MailKit.Net.Smtp;
using MimeKit;

namespace MiniSteam.Helpers
{
    public class MailHelper : IMailHelper
    {
        private readonly IConfiguration _configuration;

        public MailHelper(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public Response SendEmail(string to, string subject, string body)
        {
            var nameFrom = _configuration["Mail:NameFrom"];
            var from = _configuration["Mail:From"];
            var smtp = _configuration["Mail:Smtp"];
            var port = _configuration["Mail:Port"];
            var password = _configuration["Mail:Password"];

            if (string.IsNullOrWhiteSpace(nameFrom) ||
                string.IsNullOrWhiteSpace(from) ||
                string.IsNullOrWhiteSpace(smtp) ||
                string.IsNullOrWhiteSpace(port) ||
                string.IsNullOrWhiteSpace(password))
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = "Mail configuration is incomplete."
                };
            }

            var message = new MimeMessage();

            message.From.Add(new MailboxAddress(nameFrom, from));
            message.To.Add(new MailboxAddress(to, to));
            message.Subject = subject;

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = body
            };

            message.Body = bodyBuilder.ToMessageBody();

            try
            {
                using var client = new SmtpClient();

                client.Connect(smtp, int.Parse(port), false);
                client.Authenticate(from, password);

                client.Send(message);

                client.Disconnect(true);
            }
            catch (Exception exception)
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = exception.Message
                };
            }

            return new Response
            {
                IsSuccess = true
            };
        }
    }
}