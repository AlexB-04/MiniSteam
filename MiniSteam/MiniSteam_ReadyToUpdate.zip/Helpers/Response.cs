﻿namespace MiniSteam.Helpers
{
    public class Response
    {
        public bool IsSuccess { get; set; }

        public string Message { get; set; } = string.Empty;
    }
}